// 11) Convierta a double y float norma IEEE 754 el numero: N = 6.225. Realice el calculo de
// manera explicita y luego corrobore el resultado mediante un programa que aproveche las 
// herramientas provistas en el ejercicio 9. 
// Analizar en cada caso si se ha cometido error de representacion
// y en caso afirmativo la magnitud del mismo.

/* 
Conversion a flotante (IEEE 754 32 bits simple precisión - float)
N = 6.225 = (-1)⁰ * 6.225 * 2⁰ = (-1)⁰ * 1.55625 * 2² = (-1)⁰ * 1.55625 * 2¹²⁷⁺²
Luego el exponente mas el sesgo que se guarda en memoria es 129 = 0b10000001 = 0x81
Por otro lado hagamos la cuenta para la fracción del significante que se guarda en memoria:
    0.55625 | 1
    0.1125  | 0
    0.225   | 0
    0.45    | 0
    0.9     | 1
    0.8     | 1
    0.6     | 1
    0.2     | 0
    0.4     | 0
    0.8     | 1 y se repite infinitamente el bucle 1100.
por lo tanto la fraccion guardada en memoria es:
0.55625 (significante - 1) =(aprox) 0b10001110011001100110011 =(aprox) 0x473333
finalmente,
IEEE754_32_bits(N) = 0b01000000110001110011001100110011

Conversion a flotante (IEEE 754 64 bits doble precisión - double)
Con el mismo análisis y sesgo 1023 tenemos
exponente: 1025 = 0b10000000001
fraccion: 0.55625 =(aprox) 0b1000111001100110011001100110011001100110011001100110 = 0x8E66666666666
IEEE754_64_bits(N) = 0b0100000000011000111001100110011001100110011001100110011001100110

Error de representación IEEE 754 32 bits (float)
Error = |N - IEEE754_32_bits(N)| = 
1.100011100110011001100110011...
-
1.10001110011001100110011
--------------------------------
0.0000000000000000000000000110011... 
= 
0.(1100)periodico * 2⁻²⁵ 
= 
0.8 * 2⁻²⁵

Error de representación IEEE754 64 bits (double)
Error = |N - IEEE754_64_bits(N)| = 
1.10001110011001100110011001100110011001100110011001100110...
-
1.1000111001100110011001100110011001100110011001100110
--------------------------------------------------------------
0.0000000000000000000000000000000000000000000000000000(0110)periodico
=
0.4 * 2⁻⁵² 
=
0.8 * 2⁻⁵³
*/



#include "9.c"
#include <stdio.h>

int main(){
    // en el siguiente programa se pueden observar que los resultados encontrados para float
    // son correctos.
    float N = 6.225;
    printf("exponente: %x - ", extraer_exponente(N));
    printf("fraccion: %x - ", extraer_mantisa(N));
}