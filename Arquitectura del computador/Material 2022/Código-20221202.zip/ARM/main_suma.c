#include<stdio.h>

int suma_2(int, int);

int main(){
        int a=4, b=5;
        printf("La suma es %d\n",suma_2(a,b));
        return 0;
}
