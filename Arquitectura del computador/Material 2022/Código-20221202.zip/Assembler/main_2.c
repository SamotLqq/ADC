int suma(int, int, int, int, int, int, int, int);


#include<stdio.h>
int main(){
	int a=99,b=45, c=67, d=89, e=99, f=100, g=101, h=109;
	return suma(a,b,c,d,e,f,g,h);
	}
