int suma(int a,int b, int c, int d, int e,int f,int g,int h){
 return a+b+c+d+e+f+g+h;
 }
