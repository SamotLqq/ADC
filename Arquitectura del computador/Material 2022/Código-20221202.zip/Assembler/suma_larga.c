#include <stdio.h>

int suma(int a, int b, int c, int d, int e, int f, int g, int h){
    return a+b+c+d+e+f+g+h;
}

int main()
{
    printf("Suma = %d\n", suma(1,2,3,4,5,6,7,8));
    return 0;
}
