int calc(int, int);
int x=88;

#include<stdio.h>
int main(){
	int a=99;
	return calc(a,x);
	}
